const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
app.use(cors());
app.use(express.json());
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Démonstration uniquement : mémoire volatile (pas de base persistante).
const drivers = new Map();
const rides = new Map();

const validCoord = (lat, lon) =>
  Number.isFinite(lat) && Number.isFinite(lon) &&
  lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;

app.get('/', (_req, res) => res.json({ app: 'MOUSKI VTC live GPS starter', status: 'running' }));

app.post('/api/drivers/:driverId/location', (req, res) => {
  const { lat, lon } = req.body || {};
  if (!validCoord(lat, lon)) return res.status(400).json({ error: 'Coordonnées GPS invalides.' });
  const location = { driverId: req.params.driverId, lat, lon, updatedAt: new Date().toISOString() };
  drivers.set(req.params.driverId, location);
  io.emit('driver-location', location);
  res.json({ ok: true, location });
});

app.get('/api/drivers/:driverId/location', (req, res) => {
  const loc = drivers.get(req.params.driverId);
  if (!loc) return res.status(404).json({ error: 'Position non reçue.' });
  res.json(loc);
});

app.post('/api/rides/:rideId/pickup', (req, res) => {
  const { lat, lon } = req.body || {};
  if (!validCoord(lat, lon)) return res.status(400).json({ error: 'Coordonnées GPS invalides.' });
  const pickup = { rideId: req.params.rideId, lat, lon, updatedAt: new Date().toISOString() };
  rides.set(req.params.rideId, pickup);
  res.json({ ok: true, pickup });
});

app.get('/api/rides/:rideId/approach/:driverId', async (req, res) => {
  const pickup = rides.get(req.params.rideId);
  const driver = drivers.get(req.params.driverId);
  if (!pickup || !driver) return res.status(404).json({ error: 'Il manque le GPS du client ou du chauffeur.' });
  try {
    // OSRM route service (public demo endpoint; production should use a managed/reliable service).
    const url = `https://router.project-osrm.org/route/v1/driving/${driver.lon},${driver.lat};${pickup.lon},${pickup.lat}?overview=false`;
    const response = await fetch(url);
    if (!response.ok) throw new Error('Routing error');
    const data = await response.json();
    if (!data.routes?.length) return res.status(404).json({ error: 'Itinéraire non trouvé.' });
    const route = data.routes[0];
    const result = {
      rideId: req.params.rideId, driverId: req.params.driverId,
      distanceMeters: route.distance, etaSeconds: route.duration,
      etaMinutes: Math.ceil(route.duration / 60), calculatedAt: new Date().toISOString()
    };
    io.emit('approach-update', result);
    res.json(result);
  } catch {
    res.status(503).json({ error: 'Calcul d’itinéraire indisponible pour le moment.' });
  }
});

io.on('connection', socket => {
  socket.emit('server-status', { status: 'connected' });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`MOUSKI VTC backend listening on ${PORT}`));

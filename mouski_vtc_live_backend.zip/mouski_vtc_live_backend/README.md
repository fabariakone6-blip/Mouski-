# MOUSKI VTC — serveur GPS en direct (starter)

Prototype de backend Node.js + Express + Socket.IO.

## Démarrer
1. Installer Node.js (version 18+).
2. Dans ce dossier : `npm install`
3. `npm start`
4. Serveur local : http://localhost:3000

## Endpoints
- `POST /api/drivers/:driverId/location` — enregistre position chauffeur (lat, lon).
- `GET /api/drivers/:driverId/location` — dernière position reçue.
- `POST /api/rides/:rideId/pickup` — enregistre point client (lat, lon).
- `GET /api/rides/:rideId/approach/:driverId` — estime la distance et ETA via OSRM.

Socket.IO émet `driver-location` pour les positions et `approach-update` pour les estimations.

⚠️ Starter technique : pas d'authentification, de base de données persistante, de TLS, ni de déploiement. Ne l'utilisez pas en production sans ces protections.
